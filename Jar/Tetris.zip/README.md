#TO RUN THE JAR
The following files need to be on the same location as the jar.
-	freeBackground.jpg
-	highscore.txt
-	quotes.txt
